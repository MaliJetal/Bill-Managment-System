<!doctype html>
<html>
	<head>
			<title>PayItDesk</title>
			<link rel="stylesheet" type="text/css" href="styles/global.css" >
			<meta name="viewport" content="width=device-width initial-scale=1">
   </head>

<?php

include_once 'header.php';

?>