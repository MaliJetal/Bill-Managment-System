<!doctype html>
<html>
  <head>
      <title>PayItDesk</title>
      <link rel="stylesheet" type="text/css" href="styles/global.css" >
      <meta name="viewport" content="width=device-width initial-scale=1">
   </head>
  <body>
    <?php
      include_once'header.php';
    ?>
      <div class="icons">
      <ul><p style="color:#e4e4e4;font-size: 5em;text-align:center">A Convenient and Smart Way</p><br>
          <li><img src="images/user.png" alt="" style="width:250px ;height:auto;margin-right: 70px;margin-top:20px;"></li>
             <li><img src="images/cc.png" alt="" style="width:250px ;height:auto; margin-right: 70px;margin-top:20px;"></li>
            <li><img src="images/invoice.png" alt="" style="width:250px ;height:auto; margin-right: 70px;margin-top:20px;"></li>
          </ul> 
      
      </div>
      <hr>
      <div id="slider" style="width:100%">
      <figure>
        <img src="images/i1.jpg">
        <img src="images/i2.jpg">
        <img src="images/i3.png">
        <img src="images/i4.jpg">
        <img src="images/i5.jpg">
      </figure>
      </div>
    <hr>
    <a href="terms.php"><h1><b><p style="background-color: #ECEFF1;width:100%;height:250px;text-align:center;" >Terms And Conditions</p></b></h1></a>
  </body>
</html>