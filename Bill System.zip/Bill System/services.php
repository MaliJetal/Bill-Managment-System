<html>
	<head>
		<link rel="stylesheet" type="text/css" href="styles/global.css" >
		<style>
		.serve
		{
				    background-color: lightgrey;
				    width: 95%;
				    height:auto;
				   border: 10px solid navy;
				    padding: 25px;
				    margin: auto;
				    margin-top: 50px;
				    font-size: 1em;
				    text-align: justify;
				    color:#228B22;
        }
        .para{
        	margin-left: 25px;
        	padding-top: 70px;
        	margin-right: 25px;
        	font-size:1.6em;
        	color:#004D40;
        	font-family: 'Metal Mania', cursive;

        }
		</style>
	</head>
	<?php
			include_once'header.php';
	?>
	<body>
		<div class="para"><i><b>Our range of services include Electricity and Gas Payment and Phone Recharge.Every household consumes services like electricity, telephone,mobiles, gas, water etc. which lead to at least 2-5 bills to be paid for every household on a monthly basis. PayItDesk proprietary web platform enables easy payments for various service providers through one single web login.
            PayItDesk India has been authorized to create retail agents to accept and process bills for several utility service providers.</b></i></h4>
	<div class="serve">
				<u>Types of bill payment</u><br>
				<br>
				Electricity Bill<br>
				Postpaid Mobile Bill<br>
				Cooking Gas Bill<br>
				Landline phone Bill<br>
				*Services may vary from region to region<hr>

				<u>Service Providers</u><br>

				BEST<br>
				Reliance Energy<br>
				MTNL<br>
				BSNL<br>
				Mahanagar Gas Limited<br>
				BSES<br>
				CSPDCL<br>
				NDPL<br>
				MCGM<hr>
				<u>About Utility+</u><br>

				To start the bill payment service, a retailer must have a counter to deal with customers, a PC connected with Internet and a printer. After the quick registration process it is extremely easy to start using the service through Pay Point India's business portal.<br>
				The benefits includes:<br>

				Easy accessibility - faster access to make all payments from a single login.<br>
				Transaction & commission information available online & real-time.<br>
				Complete control - you can decide when to pay & how much to pay.<br>
				Easy to use - an easy user interface and site map, only a fewclicks for all payments.<br>
				Secure platform for all operations in a secure environment.<br>
				Competitive margins on all payments.<hr>
				<u>What does the retailer get ?</u><br>
				Access to PayItDesk portal with user ID and Password<br>
				Product Training<br>
				Branding Material like banner, Posters etc<br>
				Logo/Stickers/Leaflets/Contact Matrix<br>
				Commission Structure<br>
				Many other complimentary services<hr>
				<u>What does the retailer need?</u><br>
				PC<br>
				Internet Connectivity<br>
				Printer<br>
				Office or Retail Outlet<hr>
				<u>What documents are required?</u><br>
				Application form<br>
				2 passport size photo's<br>
				PAN Card<br>
				Shop License<br>
				Scan copy of payment proof<br>
				Any One Address Proof (Electricity Bill, Telephone Bill, Voting Card, Passport, Ration Card etc.)<hr>
				<u>Application process</u><br>
				PayItDesk India office receives the application<br>
				Sent to due diligence team for approval<br>
				On approval, services assigned to your Account<br>
				Welcome kit dispatched<br>
				Complimentary services<br>

				<a href="login.php"><p style="text-align:center;">Interested? Click here to Register</p></a>


	</div>

	</body>
</html>