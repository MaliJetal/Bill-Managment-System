<?php
 
 $conn = mysqli_connect("localhost","root","","obps");
if(!$conn){
	die("Connection failed: ".mqsqli_connect_error());
}


?>
